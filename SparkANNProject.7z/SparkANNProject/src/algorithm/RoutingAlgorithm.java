package algorithm;

import java.io.Serializable;

public abstract class RoutingAlgorithm implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
