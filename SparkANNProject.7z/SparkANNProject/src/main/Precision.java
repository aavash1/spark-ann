package main;

public enum Precision {

	DOUBLE, SINGLE;
}
